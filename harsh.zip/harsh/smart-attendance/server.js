const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const QRCode = require("qrcode");

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.json());
app.use(express.static("public"));

let currentSession = null;
let attendanceData = [];

const LOCAL_IP = "192.168.10.205"; // Your IP

// START SESSION
app.post("/start-session", async (req, res) => {

    currentSession = Math.random().toString(36).substring(2, 8);
    attendanceData = [];

    const qrData = `http://${LOCAL_IP}:3000/student.html?session=${currentSession}`;

    const qrImage = await QRCode.toDataURL(qrData);

    res.json({
        session: currentSession,
        qr: qrImage,
        link: qrData
    });
});

// MARK ATTENDANCE
app.post("/mark-attendance", (req, res) => {

    const { session, name, lat, lon } = req.body;

    if (!currentSession || session !== currentSession) {
        return res.status(400).json({ message: "Invalid session" });
    }

    const record = {
        name,
        lat,
        lon,
        time: new Date().toLocaleTimeString()
    };

    attendanceData.push(record);

    io.emit("new-attendance", record);

    res.json({ message: "Attendance marked successfully" });
});

// GET ATTENDANCE
app.get("/attendance", (req, res) => {
    res.json(attendanceData);
});

io.on("connection", () => {
    console.log("Client connected");
});

server.listen(3000, "0.0.0.0", () => {
    console.log(`Server running on http://${LOCAL_IP}:3000`);
});